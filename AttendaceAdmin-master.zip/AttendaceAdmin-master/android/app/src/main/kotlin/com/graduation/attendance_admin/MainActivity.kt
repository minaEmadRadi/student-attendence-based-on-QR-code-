package com.graduation.attendance_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
