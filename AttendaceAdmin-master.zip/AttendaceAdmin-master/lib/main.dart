import 'package:attendance_admin/providers/addingProviders/AddAdmin.dart';
import 'package:attendance_admin/providers/addingProviders/addStudent.dart';
import 'package:attendance_admin/providers/addingProviders/onlyNamedObject.dart';
import 'package:attendance_admin/providers/data.dart';
import 'package:attendance_admin/providers/editor.dart';
import 'package:attendance_admin/providers/login.dart';
import 'package:attendance_admin/providers/instructorHomeProvider.dart';
import 'package:attendance_admin/screens/home/admin_home.dart';
import 'package:attendance_admin/screens/home/instructor_home.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/addingProviders/addInstructor.dart';
import 'screens/login/login_switch.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider<LoginProvider>(
          create: (context) => LoginProvider()),
      ChangeNotifierProxyProvider<LoginProvider, AddStudentProvider>(
        create: (context) => AddStudentProvider(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..dataGetter(value.token),
      ),
      ChangeNotifierProxyProvider<LoginProvider, AddInstructorProvider>(
        create: (context) => AddInstructorProvider(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..tokenGetter(value.token),
      ),
      ChangeNotifierProxyProvider<LoginProvider, AddNamedObject>(
        create: (context) => AddNamedObject(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..tokenGetter(value.token),
      ),
      ChangeNotifierProxyProvider<LoginProvider, AddAdminProvider>(
        create: (context) => AddAdminProvider(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..tokenGetter(value.token),
      ),
      ChangeNotifierProxyProvider<LoginProvider, InstructorHomeProvider>(
        create: (context) => InstructorHomeProvider(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..dataGetter(value.token, value.userId),
      ),
      ChangeNotifierProxyProvider<LoginProvider, EditorProvider>(
        create: (context) => EditorProvider(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..tokenGetter(value.token),
      ),
      ChangeNotifierProxyProvider<LoginProvider, DataProvider>(
        create: (context) => DataProvider(),
        update: (context, value, previousDataProvider) =>
            previousDataProvider..tokenGetter(value.token),
      ),
    ],
    child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Attendance Admin',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
          centerTitle: true,
          iconTheme: IconThemeData(color: Colors.white),
        ),
        primarySwatch: Colors.lightGreen,
      ),
      home: Provider.of<LoginProvider>(context).isAuth
          ? Provider.of<LoginProvider>(context).role == "admin"
              ? AdminHomePage()
              : Provider.of<LoginProvider>(context).role == "instructor"
                  ? InstructorHome()
                  : LoginSwitcher()
          : FutureBuilder(
              future: Provider.of<LoginProvider>(context, listen: false)
                  .tryAutoLogin(),
              builder: (ctx, snapShot) =>
                  snapShot.connectionState == ConnectionState.waiting
                      ? CircularProgressIndicator()
                      : LoginSwitcher(),
            ),
    );
  }
}
