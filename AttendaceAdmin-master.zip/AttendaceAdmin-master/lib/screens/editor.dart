import 'package:attendance_admin/providers/editor.dart';
import 'package:attendance_admin/utilities/colors.dart';
import 'package:attendance_admin/utilities/dropdownBorders.dart';
import 'package:attendance_admin/widgets/addingTextField.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myDialog.dart';
import 'package:attendance_admin/widgets/saveButton.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';

class Editor extends StatefulWidget {

  final Function({String name, String email,Function done, Function error}) save;
  final bool isStudent;
  final String name;
  final String email;
  final String departId;
  final String groupId;

  const Editor({this.save, this.isStudent, this.name, this.email, this.departId, this.groupId});


  @override
  _EditorState createState() => _EditorState();
}

class _EditorState extends State<Editor> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();

  final TextEditingController _emailController = TextEditingController();
  Function({String name, String email,Function done, Function error}) mySaver;
  String name;
  String email;
  String departId;
  String groupId;
  bool isStudent;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<EditorProvider>(context, listen: false).resetVariables();
    });
    mySaver = widget.save;
    name = widget.name;
    email = widget.email;
    departId = widget.departId;
    groupId = widget.groupId;
    isStudent = widget.isStudent;
    _nameController.text = name;
    _emailController.text = email;
  }

  @override
  Widget build(BuildContext context) {
    final myListenerProvider = Provider.of<EditorProvider>(context);
    final noListenerProvider =
        Provider.of<EditorProvider>(context, listen: false);
    return ModalProgressHUD(
      inAsyncCall: myListenerProvider.isLoading,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Edit",
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Stack(
          alignment: Alignment.center,
          children: [
            Background(),
           groupId != null ? ( myListenerProvider.hasDataLoaded
               ? _buildPage(email, noListenerProvider, groupId,
               myListenerProvider, departId, mySaver, isStudent ,context)
               : Futuristic(
             dataBuilder: (ctx, data) => _buildPage(
                 email, noListenerProvider, groupId,
                 myListenerProvider, departId, mySaver, isStudent ,context),
             autoStart: true,
             futureBuilder: noListenerProvider.getGroupsDeparts,
             busyBuilder: (ctx) => CircularProgressIndicator(),
             errorBuilder: (ctx, error, retry) =>  tryAgain(error.toString(),retry),
           )) : _buildPage(email, noListenerProvider, groupId,
               myListenerProvider, departId, mySaver, isStudent ,context)

          ],
        ),
      ),
    );
  }

  SingleChildScrollView _buildPage(
      String email,
      EditorProvider noListenerProvider,
      String groupId,
      EditorProvider myListenerProvider,
      String departId,
      save({String name, String email, Function done, Function error}),
      bool isStudent,
      BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: addingBGColor,
        ),
        margin: EdgeInsets.symmetric(horizontal: 24),
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AddingTextFormField(
                  myController: _nameController,
                  labelText: "Name",
                  isPassword: false,
                  isEmail: false,
                  myValidator: (value) {
                    if (value.isEmpty) {
                      return "Please enter a name";
                    } else {
                      return null;
                    }
                  },
                ),
                if (email != null)
                  AddingTextFormField(
                    myController: _emailController,
                    isPassword: false,
                    labelText: "Email",
                    isEmail: true,
                    myValidator: (value) {
                      if (value.isEmpty) {
                        return "Please enter an email";
                      } else if (!value.contains("@")) {
                        return 'Enter a valid email';
                      } else {
                        return null;
                      }
                    },
                  ),
                if (isStudent)
                  DropdownButtonFormField<String>(
                    value: myListenerProvider.groupIDs.contains(groupId)? groupId : null,
                    onSaved: (value) => noListenerProvider.saveGroupId(value),
                    onChanged: (value) =>
                        noListenerProvider.onGroupChange(value),
                    decoration: InputDecoration(
                      labelText: "Group",
                      enabledBorder: myDropdownBorders(),
                      focusedBorder: myDropdownBorders(),
                      border: myDropdownBorders(),
                      fillColor: Colors.white,
                    ),
                    items: myListenerProvider.groups.map((e) {
                      return DropdownMenuItem<String>(
                        child: Text(e.name),
                        value: e.id,
                      );
                    }).toList(),
                    style: TextStyle(color: Colors.black),
                    dropdownColor: Colors.white,
                    validator: (v) {
                      if (v == null) {
                        return "Please choose group";
                      } else {
                        return null;
                      }
                    },
                  ),
                if (isStudent &&
                    groupId == myListenerProvider.groups.last.id && !myListenerProvider.hasGroupChanged )
                  DropdownButtonFormField<String>(
                    value: myListenerProvider.departIDs.contains(departId) ? departId : null,
                    onSaved: (value) => noListenerProvider.saveDepartId(value),
                    onChanged: (value) {},
                    decoration: InputDecoration(
                      labelText: "Department",
                      enabledBorder: myDropdownBorders(),
                      focusedBorder: myDropdownBorders(),
                      border: myDropdownBorders(),
                      fillColor: Colors.white,
                    ),
                    items: myListenerProvider.departs.map((e) {
                      return DropdownMenuItem<String>(
                        child: Text(e.name),
                        value: e.id,
                      );
                    }).toList(),
                    style: TextStyle(color: Colors.black),
                    dropdownColor: Colors.white,
                    validator: (v) {
                      if (v == null) {
                        return "Please choose department";
                      } else {
                        return null;
                      }
                    },
                  ),
                if (myListenerProvider.changedGroupId != null &&
                    myListenerProvider.changedGroupId ==
                        myListenerProvider.groups.last.id)
                  DropdownButtonFormField<String>(
                    onSaved: (value) => noListenerProvider.saveDepartId(value),
                    onChanged: (value) {},
                    decoration: InputDecoration(
                      labelText: "Department",
                      enabledBorder: myDropdownBorders(),
                      focusedBorder: myDropdownBorders(),
                      border: myDropdownBorders(),
                      fillColor: Colors.white,
                    ),
                    items: myListenerProvider.departs.map((e) {
                      return DropdownMenuItem<String>(
                        child: Text(e.name),
                        value: e.id,
                      );
                    }).toList(),
                    style: TextStyle(color: Colors.black),
                    dropdownColor: Colors.white,
                    validator: (v) {
                      if (v == null) {
                        return "Please choose department";
                      } else {
                        return null;
                      }
                    },
                  ),
                SizedBox(
                  height: 16,
                ),
                saveButton((){
                  if(_formKey.currentState.validate()){
                    _formKey.currentState.save();
                    save(
                      name : _nameController.text,
                      email : _emailController.text,
                      done: (String msg) => showMyDialog(
                          context, "Done", msg, "Okay", action: () {
                        Navigator.of(context).pop();
                      }),
                      error: (String msg) => showMyDialog(
                          context, "Error occurred", msg, "Okay",
                          action: () {}),
                    );
                  }
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
