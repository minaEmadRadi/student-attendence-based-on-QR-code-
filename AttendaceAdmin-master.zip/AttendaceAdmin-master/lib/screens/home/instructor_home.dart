import 'dart:io';

import 'package:attendance_admin/providers/login.dart';
import 'package:attendance_admin/providers/instructorHomeProvider.dart';
import 'package:attendance_admin/screens/login/login_switch.dart';
import 'package:attendance_admin/utilities/colors.dart';
import 'package:attendance_admin/utilities/dropdownBorders.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myDialog.dart';
import 'package:attendance_admin/widgets/saveButton.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:provider/provider.dart';
import 'package:toast/toast.dart';

import 'attendanceRecords.dart';
import 'qr.dart';

class InstructorHome extends StatefulWidget {
  @override
  _InstructorHomeState createState() => _InstructorHomeState();
}

class _InstructorHomeState extends State<InstructorHome>
    with SingleTickerProviderStateMixin {
  final _qrFormKey = GlobalKey<FormState>();
  final _attendanceFormKey = GlobalKey<FormState>();
  TabController _controller;
  TextEditingController _dateController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final myListenerProvider = Provider.of<InstructorHomeProvider>(context);
    final noListenerProvider =
        Provider.of<InstructorHomeProvider>(context, listen: false);
    _dateController.text =
        "${Provider.of<InstructorHomeProvider>(context).courseDate.day}/${Provider.of<InstructorHomeProvider>(context).courseDate.month}/${Provider.of<InstructorHomeProvider>(context).courseDate.year}";
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Home",
            style: TextStyle(color: Colors.white),
          ),
          actions: [
            TextButton(
                onPressed: () {
                  Provider.of<LoginProvider>(context, listen: false).logout();
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => LoginSwitcher()));
                },
                child: Text(
                  "Logout",
                  style: TextStyle(color: Colors.white),
                ))
          ],
          bottom: TabBar(
            controller: _controller,
            tabs: [
              Tab(
                child: Text(
                  "Generate Qr",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              Tab(
                child: Text(
                  "Attendance Records",
                  style: TextStyle(color: Colors.white),
                ),
              )
            ],
          ),
        ),
        body: TabBarView(
          controller: _controller,
          children: [
            _buildGenerateQR(noListenerProvider, myListenerProvider, context),
            _buildAttendanceRecords(
                noListenerProvider, myListenerProvider, context)
          ],
        ),
      ),
    );
  }

  Stack _buildGenerateQR(InstructorHomeProvider noListenerProvider,
      InstructorHomeProvider myListenerProvider, BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Background(),
        myListenerProvider.hasDataLoaded
            ? _buildGenerateQrContent(
                noListenerProvider, myListenerProvider, context)
            : Futuristic(
                autoStart: true,
                futureBuilder: noListenerProvider.instructorCoursesGetter,
                errorBuilder: (ctx, error, retry) =>
                    tryAgain(error.toString(), retry),
                busyBuilder: (ctx) => CircularProgressIndicator(),
                dataBuilder: (ctx, data) {
                  return _buildGenerateQrContent(
                      noListenerProvider, myListenerProvider, context);
                },
              )
      ],
    );
  }

  SingleChildScrollView _buildGenerateQrContent(
      InstructorHomeProvider noListenerProvider,
      InstructorHomeProvider myListenerProvider,
      BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: addingBGColor,
        ),
        margin: EdgeInsets.symmetric(horizontal: 24),
        child: Form(
          key: _qrFormKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                DropdownButtonFormField<String>(
                  onChanged: (value) =>
                      noListenerProvider.saveSelectedCourse(value),
                  decoration: InputDecoration(
                    labelText: "Choose course",
                    enabledBorder: myDropdownBorders(),
                    focusedBorder: myDropdownBorders(),
                    border: myDropdownBorders(),
                    fillColor: Colors.white,
                  ),
                  items: myListenerProvider.instructorCourses.map((e) {
                    return DropdownMenuItem<String>(
                      child: Text(e.name),
                      value: e.id,
                    );
                  }).toList(),
                  style: TextStyle(color: Colors.black),
                  dropdownColor: Colors.white,
                  validator: (v) {
                    if (v == null) {
                      return "Please choose course";
                    } else {
                      return null;
                    }
                  },
                ),
                DropdownButtonFormField<String>(
                  onChanged: (value) =>
                      noListenerProvider.saveSelectedStart(value),
                  decoration: InputDecoration(
                    labelText: "Choose Start Time",
                    enabledBorder: myDropdownBorders(),
                    focusedBorder: myDropdownBorders(),
                    border: myDropdownBorders(),
                    fillColor: Colors.white,
                  ),
                  items: myListenerProvider.times.map((e) {
                    return DropdownMenuItem<String>(
                      child: Text(e),
                      value: e,
                    );
                  }).toList(),
                  style: TextStyle(color: Colors.black),
                  dropdownColor: Colors.white,
                  validator: (v) {
                    if (v == null) {
                      return "Please choose start time";
                    } else {
                      return null;
                    }
                  },
                ),
                DropdownButtonFormField<String>(
                  onChanged: (value) =>
                      noListenerProvider.saveSelectedEnd(value),
                  decoration: InputDecoration(
                    labelText: "Choose end Time",
                    enabledBorder: myDropdownBorders(),
                    focusedBorder: myDropdownBorders(),
                    border: myDropdownBorders(),
                    fillColor: Colors.white,
                  ),
                  items: myListenerProvider.times.map((e) {
                    return DropdownMenuItem<String>(
                      child: Text(e),
                      value: e,
                    );
                  }).toList(),
                  style: TextStyle(color: Colors.black),
                  dropdownColor: Colors.white,
                  validator: (v) {
                    if (v == null) {
                      return "Please choose end time";
                    } else {
                      return null;
                    }
                  },
                ),
                SizedBox(
                  height: 16,
                ),
                saveButton(() {
                  if (_qrFormKey.currentState.validate()) {
                    if (myListenerProvider.times
                            .indexOf(myListenerProvider.selectedStartTime) >
                        myListenerProvider.times
                            .indexOf(myListenerProvider.selectedEndTime)) {
                      showMyDialog(context, "Error", "End time should be after Start time", "Okay", action: (){});
                    } else {
                      noListenerProvider.encodeData();
                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => GeneratedQR()));
                    }
                  }
                }, title: "Create"),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Stack _buildAttendanceRecords(InstructorHomeProvider noListenerProvider,
      InstructorHomeProvider myListenerProvider, BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Background(),
        SingleChildScrollView(
          child: myListenerProvider.isLoading
              ? CircularProgressIndicator()
              : (myListenerProvider.isError
                  ? Center(
                      child: Text(
                        "Something went wrong",
                        style: TextStyle(fontSize: 30, color: Colors.white),
                      ),
                    )
                  : Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: addingBGColor,
                      ),
                      margin: EdgeInsets.symmetric(horizontal: 24),
                      child: Form(
                        key: _attendanceFormKey,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 24, horizontal: 16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              DropdownButtonFormField<String>(
                                onChanged: (value) => noListenerProvider
                                    .saveSelectedCourse(value),
                                decoration: InputDecoration(
                                  labelText: "Choose course",
                                  enabledBorder: myDropdownBorders(),
                                  focusedBorder: myDropdownBorders(),
                                  border: myDropdownBorders(),
                                  fillColor: Colors.white,
                                ),
                                items: myListenerProvider.instructorCourses
                                    .map((e) {
                                  return DropdownMenuItem<String>(
                                    child: Text(e.name),
                                    value: e.id,
                                  );
                                }).toList(),
                                style: TextStyle(color: Colors.black),
                                dropdownColor: Colors.white,
                                validator: (v) {
                                  if (v == null) {
                                    return "Please choose course";
                                  } else {
                                    return null;
                                  }
                                },
                              ),
                              InkWell(
                                onTap: () {
                                  showDatePicker(
                                          context: context,
                                          initialDate:
                                              myListenerProvider.courseDate,
                                          firstDate: DateTime(
                                              DateTime.now().year - 10),
                                          lastDate: DateTime(
                                              DateTime.now().year + 10))
                                      .then((selectedDate) {
                                    if (selectedDate != null) {
                                      noListenerProvider
                                          .getSelectedDate(selectedDate);
                                    }
                                  });
                                },
                                child: IgnorePointer(
                                  child: TextFormField(
                                    controller: _dateController,
                                    textAlign: TextAlign.center,
                                    decoration: InputDecoration(
                                      suffixIcon:
                                          Icon(Icons.calendar_today_outlined),
                                      prefix: Text("Date"),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 16,
                              ),
                              saveButton(() async {
                                if (_attendanceFormKey.currentState
                                    .validate()) {
                                  try {
                                    final result = await InternetAddress.lookup(
                                        'google.com');
                                    if (result.isNotEmpty &&
                                        result[0].rawAddress.isNotEmpty) {
                                      Navigator.of(context).push(
                                          MaterialPageRoute(
                                              builder: (_) =>
                                                  AttendanceRecords()));
                                    }
                                  } on SocketException catch (_) {
                                    Toast.show(
                                        "No Internet Connection", context);
                                  }
                                }
                              }, title: "Show"),
                            ],
                          ),
                        ),
                      ),
                    )),
        ),
      ],
    );
  }
}
