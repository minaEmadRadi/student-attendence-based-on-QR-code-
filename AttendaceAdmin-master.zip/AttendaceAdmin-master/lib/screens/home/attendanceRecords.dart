import 'package:attendance_admin/providers/instructorHomeProvider.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:provider/provider.dart';

class AttendanceRecords extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final myListenerProvider = Provider.of<InstructorHomeProvider>(context);
    final noListenerProvider =
    Provider.of<InstructorHomeProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: Text("Attendance Records", style: TextStyle(color: Colors.white),),
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Background(),
          Futuristic(
            autoStart: true,
            futureBuilder: noListenerProvider.fetchAttendanceRecords,
            errorBuilder: (ctx, error, retry) =>  tryAgain(error.toString(),retry),
            busyBuilder: (ctx) => CircularProgressIndicator(),
            dataBuilder: (ctx, data) {
              return myListenerProvider.notFound?
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    "No Attendance Records Found",
                    style: TextStyle(fontSize: 25, color: Colors.white),
                  ),
                ),
              ) : ListView.builder(
                itemCount: myListenerProvider.attendedStudents.length,
                itemBuilder: (ctx, i){
                  return Container(
                    padding: EdgeInsets.only(left: 8, right: 8),
                    margin: EdgeInsets.only(top: 8),
                    child: Card(
                      color: Colors.white.withOpacity(0.9),
                      elevation: 15,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(myListenerProvider.attendedStudents[i].name, style: TextStyle(color: Colors.black, fontSize: 15), ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                  constraints: BoxConstraints(
                                    minWidth: 32,
                                    minHeight: 32,
                                  ),
                                  child: Icon(Icons.check, color: Colors.green, size: 24,),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
