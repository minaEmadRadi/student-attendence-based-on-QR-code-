import 'package:attendance_admin/providers/login.dart';
import 'package:attendance_admin/screens/addingPages/add_student.dart';
import 'package:attendance_admin/screens/login/login_switch.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/drawer.dart';
import 'package:attendance_admin/widgets/myCard.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../addingPages/add_admin.dart';
import '../addingPages/add_course.dart';
import '../addingPages/add_depart.dart';
import '../addingPages/add_group.dart';
import '../addingPages/add_instructor.dart';


class AdminHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: myDrawer(context, (){
        Provider.of<LoginProvider>(context, listen: false).logout();
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=> LoginSwitcher()));
      }),
      appBar: AppBar(
        title: Text(
          "Admin",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Background(),
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  myCard(
                    txt: "Add Instructor",
                    imgUrl: 'assets/images/AddInstructor.jpg',
                    onPress: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AddInstructor()));
                    },
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  myCard(
                    txt: "Add Student",
                    imgUrl: 'assets/images/student.jpg',
                    onPress: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AddStudent()));
                    },
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  myCard(
                    txt: "Add Group",
                    imgUrl: 'assets/images/addGroup.jpg',
                    onPress: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AddGroup()));
                    },
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  myCard(
                    txt: "Add Course",
                    imgUrl: 'assets/images/Courses.jpg',
                    onPress: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AddCourse()));
                    },
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  myCard(
                    txt: "Add Department",
                    imgUrl: 'assets/images/AddDepart.jpg',
                    onPress: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AddDepart()));
                    },
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  myCard(
                    txt: "Add Admin",
                    imgUrl: 'assets/images/AddAdmin.png',
                    onPress: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AddAdmin()));
                    },
                  ),

                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
