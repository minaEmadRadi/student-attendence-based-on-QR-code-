import 'package:attendance_admin/providers/data.dart';
import 'package:attendance_admin/providers/editor.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myDialog.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:attendance_admin/widgets/viewAll.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';

import '../editor.dart';

class AllCourses extends StatefulWidget {
  @override
  _AllCoursesState createState() => _AllCoursesState();
}

class _AllCoursesState extends State<AllCourses> {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<DataProvider>(context, listen: false).resetDataLoadingVariable();
    });
  }

  @override
  Widget build(BuildContext context) {
    final noListenerProvider =
    Provider.of<DataProvider>(context, listen: false);
    final myListenerProvider = Provider.of<DataProvider>(context);
    return ModalProgressHUD(
      inAsyncCall: myListenerProvider.deletionLoading,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "All Courses",
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Stack(
          alignment: Alignment.center,
          children: [
            Background(),
            RefreshIndicator(
              onRefresh: noListenerProvider.coursesGetter,
              child:
              myListenerProvider.hasDataLoaded? _buildPage(myListenerProvider, noListenerProvider, context) :
              Futuristic(
                autoStart: true,
                futureBuilder: noListenerProvider.coursesGetter,
                busyBuilder: (ctx) => CircularProgressIndicator(),
                errorBuilder: (ctx, error, retry) =>  tryAgain(error.toString(),retry),
                dataBuilder: (ctx, data) {
                  return _buildPage(myListenerProvider, noListenerProvider, context);
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  ViewAll _buildPage(DataProvider myListenerProvider, DataProvider noListenerProvider, BuildContext context) {
    return ViewAll(
                items: myListenerProvider.courses,
                dialogTitle: "Are you sure?",
                dialogContent: "Are you sure to delete this Course?",
                delete: (int i){
                  noListenerProvider.deleteObject(
                    objectType: "course",
                    id: myListenerProvider.courses[i].id,
                    done: (String msg)=> showMyDialog(context, "Done", msg, "Okay", action: () {
                    }),
                    error: (String msg)=> showMyDialog(context, "Error occurred", msg, "Okay", action: () {}),
                  ).then((_) {
                    noListenerProvider.coursesGetter();
                  });
                },
                edit: (int i) {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                        builder: (_) => Editor(
                          isStudent: false,
                          save: (
                              {String name, String email,Function done, Function error}) {
                            Provider.of<EditorProvider>(context, listen: false)
                                .editObject(
                              objectType: "course",
                              done: done,
                              name: name,
                              error: error,
                              id: myListenerProvider.courses[i].id,
                              isStudent: false,
                            )
                                .then((value) {
                              noListenerProvider.coursesGetter();
                            });
                          },
                          name:  myListenerProvider.courses[i].name,
                        ), ),
                  );
                },
              );
  }
}

