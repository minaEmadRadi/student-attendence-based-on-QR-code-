import 'package:attendance_admin/providers/data.dart';
import 'package:attendance_admin/providers/editor.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myDialog.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:attendance_admin/widgets/viewAll.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';

import '../editor.dart';

class AllStudents extends StatefulWidget {
  @override
  _AllStudentsState createState() => _AllStudentsState();
}

class _AllStudentsState extends State<AllStudents> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<DataProvider>(context, listen: false)
          .resetDataLoadingVariable();
    });
  }

  @override
  Widget build(BuildContext context) {
    final noListenerProvider =
        Provider.of<DataProvider>(context, listen: false);
    final myListenerProvider = Provider.of<DataProvider>(context);
    return ModalProgressHUD(
      inAsyncCall: myListenerProvider.deletionLoading,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "All Students",
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Stack(
          alignment: Alignment.center,
          children: [
            Background(),
            RefreshIndicator(
              onRefresh: noListenerProvider.studentsGetter,
              child: myListenerProvider.hasDataLoaded
                  ? _buildPage(myListenerProvider, noListenerProvider, context)
                  : Futuristic(
                      autoStart: true,
                      futureBuilder: noListenerProvider.studentsGetter,
                      busyBuilder: (ctx) => CircularProgressIndicator(),
                      errorBuilder: (ctx, error, retry) =>  tryAgain(error.toString(),retry),
                      dataBuilder: (ctx, data) {
                        return _buildPage(
                            myListenerProvider, noListenerProvider, context);
                      },
                    ),
            )
          ],
        ),
      ),
    );
  }

  ViewAll _buildPage(DataProvider myListenerProvider,
      DataProvider noListenerProvider, BuildContext context) {
    return ViewAll(
      items: myListenerProvider.students,
      dialogTitle: "Are you sure?",
      dialogContent: "Are you sure to delete this Student?",
      delete: (int i) {
        noListenerProvider
            .deleteObject(
          objectType: "user",
          id: myListenerProvider.students[i].id,
          done: (String msg) =>
              showMyDialog(context, "Done", msg, "Okay", action: () {}),
          error: (String msg) => showMyDialog(
              context, "Error occurred", msg, "Okay",
              action: () {}),
        )
            .then((_) {
          noListenerProvider.studentsGetter();
        });
      },
      edit: (int i) {
        Navigator.of(context).push(
          MaterialPageRoute(
              builder: (_) => Editor(
                isStudent: true,
                save: (
                    { String name, String email ,Function done,
                      Function error}) {
                  Provider.of<EditorProvider>(context, listen: false)
                      .editObject(
                    objectType: "user",
                    done: done,
                    name: name,
                    email: email,
                    error: error,
                    id: myListenerProvider.students[i].id,
                    isStudent: true,
                  )
                      .then((_) {
                    noListenerProvider.studentsGetter();
                  });
                },
                name: myListenerProvider.students[i].name,
                email: myListenerProvider.students[i].email,
                departId: myListenerProvider.students[i].departId,
                groupId: myListenerProvider.students[i].groupId,
              ),
              ),
        );
      },
    );
  }
}
