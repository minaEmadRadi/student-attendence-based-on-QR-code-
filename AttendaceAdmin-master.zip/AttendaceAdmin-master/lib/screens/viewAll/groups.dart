import 'package:attendance_admin/providers/data.dart';
import 'package:attendance_admin/providers/editor.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myDialog.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:attendance_admin/widgets/viewAll.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';

import '../editor.dart';

class AllGroups extends StatefulWidget {
  @override
  _AllGroupsState createState() => _AllGroupsState();
}

class _AllGroupsState extends State<AllGroups> {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<DataProvider>(context, listen: false).resetDataLoadingVariable();
    });
  }

  @override
  Widget build(BuildContext context) {
    final noListenerProvider =
    Provider.of<DataProvider>(context, listen: false);
    final myListenerProvider = Provider.of<DataProvider>(context);
    return ModalProgressHUD(
      inAsyncCall: myListenerProvider.deletionLoading,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "All Groups",
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Stack(
          alignment: Alignment.center,
          children: [
            Background(),
            RefreshIndicator(
              onRefresh: noListenerProvider.groupsGetter,
              child:
              myListenerProvider.hasDataLoaded? _buildPage(myListenerProvider, noListenerProvider, context) :
              Futuristic(
                autoStart: true,
                futureBuilder: noListenerProvider.groupsGetter,
                busyBuilder: (ctx) => CircularProgressIndicator(),
                errorBuilder: (ctx, error, retry) =>  tryAgain(error.toString(),retry),
                dataBuilder: (ctx, data) {
                  return _buildPage(myListenerProvider, noListenerProvider, context);
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  ViewAll _buildPage(DataProvider myListenerProvider, DataProvider noListenerProvider, BuildContext context) {
    return ViewAll(
                items: myListenerProvider.groups,
                dialogTitle: "Are you sure?",
                dialogContent: "Are you sure to delete this Group?",
                delete: (int i){
                  noListenerProvider.deleteObject(
                    objectType: "group",
                    id: myListenerProvider.groups[i].id,
                    done: (String msg)=> showMyDialog(context, "Done", msg, "Okay", action: () {
                    }),
                    error: (String msg)=> showMyDialog(context, "Error occurred", msg, "Okay", action: () {}),
                  ).then((_){
                    noListenerProvider.groupsGetter();
                  });
                },
                edit: (int i) {
                  Navigator
                      .of(context)
                      .push(
                      MaterialPageRoute(
                          builder: (_) => Editor(
                            isStudent: false,
                            save: (
                                {String name, String email,Function done, Function error}) {
                              Provider.of<EditorProvider>(
                                  context, listen: false).editObject(
                                objectType: "group",
                                done: done,
                                email: email,
                                name: name,
                                error: error,
                                id: myListenerProvider.groups[i].id,
                                isStudent: false,
                              ).then((value) {
                                noListenerProvider.groupsGetter();
                              });
                            },
                            name: myListenerProvider.groups[i].name,

                          ),),
                    ); } );

  }
}


