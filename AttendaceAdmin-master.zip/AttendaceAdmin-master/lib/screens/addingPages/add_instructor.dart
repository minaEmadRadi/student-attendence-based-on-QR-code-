import 'package:attendance_admin/providers/addingProviders/addInstructor.dart';
import 'package:attendance_admin/providers/data.dart';
import '../../utilities/passwordNumValidator.dart';
import 'package:attendance_admin/utilities/colors.dart';
import 'package:attendance_admin/utilities/dropdownBorders.dart';
import 'package:attendance_admin/widgets/addingTextField.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/saveButton.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import '../../widgets/myDialog.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:provider/provider.dart';

class AddInstructor extends StatefulWidget {
  @override
  _AddInstructorState createState() => _AddInstructorState();
}

class _AddInstructorState extends State<AddInstructor> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();

  final TextEditingController _emailController = TextEditingController();

  final TextEditingController _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<AddInstructorProvider>(context, listen: false).resetCoursesLoading();
    });
  }

  @override
  Widget build(BuildContext context) {
    final myListenerProvider = Provider.of<AddInstructorProvider>(context);
    final noListenerProvider =
        Provider.of<AddInstructorProvider>(context, listen: false);

    return ModalProgressHUD(
      inAsyncCall: myListenerProvider.isLoading,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Add Instructor",
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
        ),
        body: Stack(
          alignment: Alignment.center,
          children: [
            Background(),
            myListenerProvider.hasCoursesLoaded
                ? _buildPage(
                    myListenerProvider, noListenerProvider, context)
                : Futuristic(
                    autoStart: true,
                    busyBuilder: (ctx) => CircularProgressIndicator(),
                    errorBuilder: (ctx, error, retry) => tryAgain(error.toString(),retry),
                    futureBuilder:
                        noListenerProvider
                            .coursesGetter,
                    dataBuilder: (ctx, data) => _buildPage(
                         myListenerProvider, noListenerProvider, context),
                  )
          ],
        ),
      ),
    );
  }

  Widget _buildPage(AddInstructorProvider myListenerProvider,
      AddInstructorProvider noListenerProvider, BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: addingBGColor,
        ),
        margin: EdgeInsets.symmetric(horizontal: 24),
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AddingTextFormField(
                  key: ValueKey("name"),
                  isPassword: false,
                  isEmail: false,
                  labelText: "Name",
                  myValidator: (value) {
                    if (value.isEmpty) {
                      return "Please enter a name";
                    } else {
                      return null;
                    }
                  },
                  myController: _nameController,
                ),
                AddingTextFormField(
                  key: ValueKey("email"),
                  isPassword: false,
                  isEmail: true,
                  labelText: "Email",
                  myValidator: (value) {
                    if (value.isEmpty) {
                      return "Please enter an email";
                    } else if (!value.contains("@")) {
                      return 'Enter a valid email';
                    } else {
                      return null;
                    }
                  },
                  myController: _emailController,
                ),
                AddingTextFormField(
                  key: ValueKey("pass"),
                  isPassword: true,
                  isEmail: false,
                  labelText: "Password",
                  myValidator: (value) {
                    if (value.isEmpty) {
                      return "Please enter a password";
                    } else if (value.length < 8) {
                      return "Too short password";
                    } else if (passwordNotContainsNum(value)) {
                      return "Password must consist of alphabets & numbers";
                    } else {
                      return null;
                    }
                  },
                  myController: _passwordController,
                ),
                DropdownButtonFormField<String>(
                  key: ValueKey("1st"),
                  onSaved: (value) =>
                      noListenerProvider.addCourseIdToList(value),
                  onChanged: (value) {},
                  decoration: InputDecoration(
                    suffixIcon: IconButton(
                      onPressed: noListenerProvider.addMoreCourse,
                      icon: Icon(
                        Icons.add,
                        color: Colors.blue,
                      ),
                    ),
                    labelText: "Courses",
                    enabledBorder: myDropdownBorders(),
                    focusedBorder: myDropdownBorders(),
                    border: myDropdownBorders(),
                    fillColor: Colors.white,
                  ),
                  items: myListenerProvider.courses
                      .map((e) {
                    return DropdownMenuItem<String>(
                      child: Text(e.name),
                      value: e.id,
                    );
                  }).toList(),
                  style: TextStyle(color: Colors.black),
                  dropdownColor: Colors.white,
                  validator: (v) {
                    if (v == null) {
                      return "Please choose course";
                    } else {
                      return null;
                    }
                  },
                ),
               ...(myListenerProvider.myDropDowns.map((key, value) => MapEntry(key, value)).values.toList()),
                SizedBox(
                  height: 16,
                ),
                saveButton(() async {
                  if (_formKey.currentState.validate()) {
                    _formKey.currentState.save();
                    await noListenerProvider.createNewInstructor(
                      myEmail: _emailController.text,
                      myPassword: _passwordController.text,
                      myName: _nameController.text,
                      done: (String msg)=> showMyDialog(context, "Done", msg, "Okay", action: () {
                        Navigator.of(context).pop();
                      }),
                      error:(String msg)=> showMyDialog(context, "Error occurred", msg, "Okay", action: () {}),
                    );
                  }
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
