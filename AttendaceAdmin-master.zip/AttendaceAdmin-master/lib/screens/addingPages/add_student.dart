import 'package:attendance_admin/providers/addingProviders/addStudent.dart';
import 'package:attendance_admin/utilities/colors.dart';
import 'package:attendance_admin/utilities/passwordNumValidator.dart';
import 'package:attendance_admin/widgets/addingTextField.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myDialog.dart';
import 'package:attendance_admin/widgets/myDropdownMenu.dart';
import 'package:attendance_admin/widgets/saveButton.dart';
import 'package:attendance_admin/widgets/tryAgainButton.dart';
import 'package:flutter/material.dart';
import 'package:futuristic/futuristic.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';


class AddStudent extends StatelessWidget {
  final  _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    final myListenerProvider = Provider.of<AddStudentProvider>(context);
    final noListenerProvider = Provider.of<AddStudentProvider>(context, listen: false);

    return ModalProgressHUD(
      inAsyncCall: myListenerProvider.isLoading,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "Add Student",
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
        ),
        body: Stack(
          alignment: Alignment.center,
          children: [
            Background(),
             myListenerProvider.hasDataLoaded? _buildPageContent(noListenerProvider, myListenerProvider, context) :
             Futuristic(
               autoStart: true,
               futureBuilder: noListenerProvider.getGroupsDeparts,
               busyBuilder: (ctx)=> CircularProgressIndicator(),
               errorBuilder: (ctx, error, retry) => tryAgain(error.toString(),retry),
               dataBuilder: (ctx, data) => _buildPageContent(noListenerProvider, myListenerProvider, context),
             ),
          ],
        ),
      ),
    );
  }

 _buildPageContent(AddStudentProvider noListenerProvider, AddStudentProvider myListenerProvider, BuildContext context)  {
    return SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: addingBGColor,
            ),
            margin: EdgeInsets.symmetric(horizontal: 24),
            child: Form(
              key: _formKey,
              child: Padding(
                padding:
                const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AddingTextFormField(
                      isPassword: false,
                      isEmail: false,
                      labelText: "Name",
                      myController: _nameController,
                      myValidator: (value) {
                        if (value.isEmpty) {
                          return "Please enter a name";
                        } else {
                          return null;
                        }
                      },
                    ),
                    AddingTextFormField(
                      isPassword: false,
                      isEmail: true,
                      labelText: "Email",
                      myController: _emailController,
                      myValidator: (value) {
                        if (value.isEmpty) {
                          return "Please enter an email";
                        } else if (!value.contains("@")) {
                          return 'Enter a valid email';
                        } else {
                          return null;
                        }
                      },
                    ),
                    AddingTextFormField(
                      isPassword: true,
                      isEmail: false,
                      labelText: "Password",
                      myController: _passwordController,
                      myValidator: (value) {
                        if (value.isEmpty) {
                          return "Please enter a password";
                        } else if (value.length < 8) {
                          return "Too short password";
                        } else if (passwordNotContainsNum(value)) {
                          return "Password must consist of alphabets & numbers";
                        } else {
                          return null;
                        }
                      },
                    ),
                    myDropdownMenu(
                      onChanged: (value)=> noListenerProvider.saveGroupID(value),
                      labelText: "Select group",
                      validatorText: "Please choose group",
                      dropdownItems: myListenerProvider.groups.map((e){
                        return DropdownMenuItem<String>(
                          child: Text(e.name),
                          value: e.id,
                        );
                      }).toList(),
                    ),
                   if(myListenerProvider.selectedGroup == myListenerProvider.groups.last) myDropdownMenu(
                      onChanged: (value)=> noListenerProvider.saveDepartID(value),
                      labelText: "Select Department",
                      validatorText: "Please choose department",
                      dropdownItems: myListenerProvider.departs.map((e){
                        return DropdownMenuItem<String>(
                          child: Text(e.name),
                          value: e.id,
                        );
                      }).toList(),
                    ),
                    SizedBox(height: 16,),
                    saveButton(() async{
                      if(_formKey.currentState.validate()){
                        await noListenerProvider.createNewStudent(
                          myEmail: _emailController.text,
                          myPassword: _passwordController.text,
                          myName: _nameController.text,
                          done: (String msg)=> showMyDialog(context, "Done", msg, "Okay", action: () {
                            Navigator.of(context).pop();
                          }),
                          error:(String msg)=> showMyDialog(context, "Error occurred", msg, "Okay", action: () {}),
                        );
                      }
                    }),
                  ],
                ),
              ),
            ),
          ),
        );
  }
}
