import 'dart:io';

import 'package:attendance_admin/providers/login.dart';
import 'package:attendance_admin/widgets/login.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:toast/toast.dart';
import '../home/admin_home.dart';

class AdminLogin extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: Provider.of<LoginProvider>(context).isLoading,
      child: Login(
        title: "Login as Admin",
        loginFunction: () async {
          try {
            final result = await InternetAddress.lookup('google.com');
            if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
              try {
                await Provider.of<LoginProvider>(context, listen: false)
                    .adminLogin(done:(){
                  Navigator.of(context).pop();
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => AdminHomePage()));
                },
                  error: (){
                    showDialog(
                        context: context,
                        builder: (ctx) {
                          return AlertDialog(
                            title: Text("You're not admin"),
                            content: Text(
                                "You don't have the permission to access admin panel"),
                            actions: [
                              TextButton(
                                  onPressed: () => Navigator.of(ctx).pop(),
                                  child: Text("Okay"))
                            ],
                          );
                        });
                  }
                );
              } catch (error) {
                showDialog(
                    context: context,
                    builder: (ctx) {
                      return AlertDialog(
                        title: Text("Error occurred"),
                        content:
                            Text(error),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.of(ctx).pop(),
                              child: Text("Okay"))
                        ],
                      );
                    });
              }
            }
          } on SocketException catch (_) {
            Toast.show("No Internet Connection", context);
          }
        },
      ),
    );
  }
}
