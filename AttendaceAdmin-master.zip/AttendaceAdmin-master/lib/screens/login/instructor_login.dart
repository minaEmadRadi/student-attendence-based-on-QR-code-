import 'dart:io';

import 'package:attendance_admin/providers/login.dart';
import 'package:attendance_admin/screens/home/instructor_home.dart';
import 'package:attendance_admin/widgets/login.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:provider/provider.dart';
import 'package:toast/toast.dart';

class InstructorLogin extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: Provider.of<LoginProvider>(context).isLoading,
      child: Login(
        title: "Login as Instructor",
        loginFunction: () async {
          try {
            final result = await InternetAddress.lookup('google.com');
            if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
              try {
                await Provider.of<LoginProvider>(context, listen: false)
                    .instructorLogin(done: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => InstructorHome()));
                }, error: () {
                  showDialog(
                      context: context,
                      builder: (ctx) {
                        return AlertDialog(
                          title: Text("You're not instructor"),
                          content: Text(
                              "You don't have the permission to access instructor panel"),
                          actions: [
                            TextButton(
                                onPressed: () => Navigator.of(ctx).pop(),
                                child: Text("Okay"))
                          ],
                        );
                      });
                });
              } catch (error) {
                showDialog(
                    context: context,
                    builder: (ctx) {
                      return AlertDialog(
                        title: Text("Error occurred"),
                        content: Text(error),
                        actions: [
                          TextButton(
                              onPressed: () => Navigator.of(ctx).pop(),
                              child: Text("Okay"))
                        ],
                      );
                    });
              }
            }
          } on SocketException catch (_) {
            Toast.show("No Internet Connection", context);
          }
        },
      ),
    );
  }
}
