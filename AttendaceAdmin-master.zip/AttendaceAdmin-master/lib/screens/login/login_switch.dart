import 'package:attendance_admin/screens/login/admin_login.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:attendance_admin/widgets/myCard.dart';
import 'package:flutter/material.dart';


import 'instructor_login.dart';

class LoginSwitcher extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Login",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Background(),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                myCard(
                  txt: "Login as Admin",
                  imgUrl: 'assets/images/Admin.png',
                  onPress: () {
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => AdminLogin()));
                  },
                ),
                SizedBox(
                  height: 24,
                ),
                myCard(
                  txt: "Login as Instructor",
                  imgUrl: 'assets/images/Instructor.png',
                  onPress: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => InstructorLogin()));
                  },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
