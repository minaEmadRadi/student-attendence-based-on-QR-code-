
bool passwordNotContainsNum(String value){
 if( value.contains("0") ||
     value.contains("1") ||
     value.contains("2") ||
     value.contains("3") ||
     value.contains("4") ||
     value.contains("5") ||
     value.contains("6") ||
     value.contains("7") ||
     value.contains("8") ||
     value.contains("9")){
   return false;
 }else{
   return true;
 }
}