import 'package:attendance_admin/models/student.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RecordsServices {
  static Future<Map<String, Object>> fetch(Map<String, Object> data) async {
    final String url =
        'https://smartattendanceapi.herokuapp.com/api/attendance';

    http.Response response = await http.post(
      Uri.parse(url),
      headers: {
        "Content-Type": "application/json",
      },
      body: json.encode(data),
    );
    if (response.statusCode < 400) {

      Map decodedResponseBody = json.decode(response.body);
      List responseAttendance = decodedResponseBody['attendance'];
      List<Student> students = responseAttendance.map((element) {
        return Student.fromJson(element['student']);
      }).toList();

      return {"notFound": false, "students": students};
    } else if (response.statusCode == 404) {
      return {"notFound": true};
    } else {
      throw "Failed to load";
    }
  }
}
