import 'package:http/http.dart' as http;
import 'dart:convert';

class Deletion{
  static  Future<String> deleteObject(String urlSegment, String id, String token) async{
    final String url = "https://smartattendanceapi.herokuapp.com/api/$urlSegment/$id";
    http.Response response = await http.delete(
      Uri.parse(url),
      headers: {
        'AUTHORIZATION': 'Bearer $token'
      },
    );

    Map<String, Object> decodedRes = json.decode(response.body);

    if (response.statusCode < 400) {
      String message = decodedRes['message'];
      return message;
    } else {
      var errorMsg = decodedRes['message'];
      throw errorMsg;
    }
  }

}