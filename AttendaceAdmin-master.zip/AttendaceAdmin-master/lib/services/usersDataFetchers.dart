import 'package:attendance_admin/models/admin.dart';
import 'package:attendance_admin/models/instructor.dart';
import 'package:attendance_admin/models/student.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

final String _failed = "Failed to load";

Future<List<Instructor>> fetchInstructors() async {
  final String url =
      'https://smartattendanceapi.herokuapp.com/api/user?role=instructor';

  http.Response response = await http.get(
    Uri.parse(url),
  );

  if (response.statusCode == 200) {
    Map decodedResponseBody = json.decode(response.body);
    List responseInstructors = decodedResponseBody['users'];
    List<Instructor> instructors = responseInstructors.map((element) {
      return Instructor.fromJson(element);
    }).toList();
    return instructors;
  }else if(response.statusCode == 404){
    throw "No Instructors Yet";
  }
  else {
    throw _failed;
  }
}

Future<List<Student>> fetchStudents() async {
  final url =
      'https://smartattendanceapi.herokuapp.com/api/user?role=student';
  http.Response response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Map decodedResponseBody = json.decode(response.body);
    List responseStudents = decodedResponseBody['users'];
    List<Student> students = responseStudents.map((element) {
      return Student.fromJson(element);
    }).toList();
    return students;
  }else if(response.statusCode == 404){
    throw "No Students Yet";
  }
  else {
    throw _failed;
  }
}

Future<List<Admin>> fetchAdmins() async {
  final url = 'https://smartattendanceapi.herokuapp.com/api/user?role=admin';
  http.Response response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Map decodedResponseBody = json.decode(response.body);
    List responseAdmins = decodedResponseBody['users'];
    List<Admin> admins = responseAdmins.map((element) {
      return Admin.fromJson(element);
    }).toList();
    return admins;
  } else {
    throw _failed;
  }
}

Future<List> fetchSpecificInstructorCourses(String id) async {
  final String url = 'https://smartattendanceapi.herokuapp.com/api/user/$id';
  http.Response response = await http.get(Uri.parse(url));
  if (response.statusCode == 200) {
    Map decodedResponseBody = json.decode(response.body);
    Map instructorData = decodedResponseBody['user'];
    List instructorCourses = instructorData['courses'];
    return instructorCourses;
  } else {
    throw _failed;
  }
}
