import 'package:attendance_admin/models/course.dart';
import 'package:attendance_admin/models/department.dart';

import '../models/group.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class DataFetchers {
  static Future<List<Group>> fetchGroups() async {
    final String url = 'https://smartattendanceapi.herokuapp.com/api/group';

    http.Response response = await http.get(
      Uri.parse(url),
    );

    //If Status Code == 200 it means SUCCESS
    if (response.statusCode == 200) {

      //Convert The Json to List of Groups
      Map decodedResponseBody = json.decode(response.body);
      List responseGroups = decodedResponseBody['groups'];
      List<Group> groups = responseGroups.map((element) {
        return Group.fromJson(element);
      }).toList();

      return groups;
    } else {
      throw "Failed to load";
    }
  }

  static Future<List<Course>> fetchCourses() async {
    final String url = 'https://smartattendanceapi.herokuapp.com/api/course';
    http.Response response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {

      Map decodedResponseBody = json.decode(response.body);
      List responseCourses = decodedResponseBody['courses'];
      List<Course> courses = responseCourses.map((element) {
        return Course.fromJson(element);
      }).toList();

      return courses;
    } else {
      throw "Failed to load";
    }
  }

  static Future<List<Department>> fetchDeparts() async {
    final String url =
        'https://smartattendanceapi.herokuapp.com/api/department';
    http.Response response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      Map decodedResponseBody = json.decode(response.body);
      List responseDeparts = decodedResponseBody['departments'];
      List<Department> departs = responseDeparts.map((element) {
        return Department.fromJson(element);
      }).toList();
      return departs;
    } else {
      throw "Failed to load";
    }
  }

  static Future<Map<String, List<Object>>> fetchGroupsDeparts() async {
    final String url =
        'https://smartattendanceapi.herokuapp.com/api/group/department';
    http.Response response = await http.get(Uri.parse(url));
    if (response.statusCode < 400) {

      Map decodedResponseBody = json.decode(response.body);

      //Departments
      List responseDeparts = decodedResponseBody['departments'];
      List<Department> departs = responseDeparts.map((element) {
        return Department.fromJson(element);
      }).toList();

      List responseGroups = decodedResponseBody['groups'];
      List<Group> groups = responseGroups.map((element) {
        return Group.fromJson(element);
      }).toList();
      Map<String, List<Object>> _map = {
        "groups": groups,
        "departs": departs,
      };

      return _map;
    } else {
      throw "Failed to load";
    }
  }
}
