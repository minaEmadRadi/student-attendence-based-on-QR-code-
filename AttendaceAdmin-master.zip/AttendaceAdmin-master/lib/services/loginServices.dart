import 'package:http/http.dart' as http;
import 'dart:convert';

class LoginService {
  static Future<Map<String, Object>> login(
      Map<String, String> loginData) async {
    final String url =
        "https://smartattendanceapi.herokuapp.com/api/auth/login";

    http.Response response = await http.post(
      Uri.parse(url),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(loginData),
    );

    Map<String, Object> decodedRes = json.decode(response.body);

    if (response.statusCode == 200) {
      Map<String, Object> userData = decodedRes['user'];
      Map<String, Object> userTokens = decodedRes['tokens'];
      Map<String, Object> userAllData = {
        'user': userData,
        'tokens': userTokens,
      };
      return userAllData;
    } else {
      String errorMsg = decodedRes['message'];
      throw errorMsg;
    }
  }
}
