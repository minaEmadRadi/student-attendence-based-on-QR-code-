import 'package:http/http.dart' as http;
import 'dart:convert';

// Client (Application) ---------->  Server (Api) Request
//1- Request Link, Request Type ,Request Data (Json)
//Server -----------> Client Response

class UserCreator {
  static Future<String> createUser({
    String token,
    String role,
    String name,
    String email,
    String password,
    List<String> courses,
    String group,
    String depart,
  }) async {
    final String url = "https://smartattendanceapi.herokuapp.com/api/user";
    Map<String, Object> myBody;
    if (role == "instructor") {
      myBody = {
        'name': name,
        'email': email,
        'role': role,
        'password': password,
        'passwordConfirmation': password,
        'courses': courses
      };
    } else if (role == "admin") {
      myBody = {
        "name": name,
        "email": email,
        "role": role,
        "password": password,
        "passwordConfirmation": password
      };
    } else if (role == "student") {
      myBody = {
        "name": name,
        "email": email,
        "role": role,
        "password": password,
        "passwordConfirmation": password,
        "department": depart,
        "group": group
      };
    }

    //Making the request
    http.Response response = await http.post(
      Uri.parse(url),
      //Doesn't Change
      headers: {
        "Content-Type": "application/json",
        'AUTHORIZATION': 'Bearer $token'
      },
      body: json.encode(myBody), //Convert Data to Json
    );

    //Response
    Map<String, Object> decodedRes = json.decode(response.body);
    if (response.statusCode < 400) {
      String message = decodedRes['message'];
      return message;
    } else {
      var errorMsg = decodedRes['message'];
      throw errorMsg;
    }
  }
}
