import 'package:http/http.dart' as http;
import 'dart:convert';

class EditorServices {
  static Future objectEditor(
      {String urlSegment ,String id, String token, Map<String, String> myBody}) async {
    final url = "https://smartattendanceapi.herokuapp.com/api/$urlSegment/$id";
    http.Response response = await http.patch(
      Uri.parse(url),
      headers: {
        "Content-Type": "application/json",
        'AUTHORIZATION': 'Bearer $token'
      },
      body: json.encode(myBody),
    );
    Map<String, Object> decodedRes = json.decode(response.body);
    if (response.statusCode < 400) {
      String message = decodedRes['message'];
      return message;
    } else {
      var errorMsg = decodedRes['message'];
      throw errorMsg; //Returning Error
    }
  }


}
