import 'package:http/http.dart' as http;
import 'dart:convert';

class NamedObjectCreator {
  static Future<String> createObject(
      {String urlSegment, String name, String token}) async {

    final url = "https://smartattendanceapi.herokuapp.com/api/$urlSegment";

    Map<String, String> myBody = {"name": name};

    http.Response response = await http.post(
      Uri.parse(url),
      headers: {
        "Content-Type": "application/json",
        'AUTHORIZATION': 'Bearer $token'
      },
      body: json.encode(myBody),
    );

    Map<String, Object> decodedRes = json.decode(response.body);

    if (response.statusCode < 400) {
      String message = decodedRes['message'];
      return message;
    } else {
      print(response.body);
      var errorMsg = decodedRes['message'];
      throw errorMsg;
    }
  }
}
