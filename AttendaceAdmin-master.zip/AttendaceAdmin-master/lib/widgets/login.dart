import 'package:attendance_admin/providers/login.dart';
import 'package:attendance_admin/widgets/authTextFormField.dart';
import 'package:attendance_admin/widgets/background.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Login extends StatelessWidget {
  final String title;
  final Function loginFunction;
  static final _formKey = GlobalKey<FormState>();

  Login({this.title, this.loginFunction});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Background(),
          SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              margin: EdgeInsets.symmetric(horizontal: 24),
              child: Form(
                key: _formKey,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Sign in to start your session"),
                      SizedBox(
                        height: 24,
                      ),
                      AuthTextField(
                        key: ValueKey("Email"),
                        labelText: "Email",
                        isPassword: false,
                        ifChanged: (value) =>
                            Provider.of<LoginProvider>(context, listen: false)
                                .getEmail(value),
                      ),
                      AuthTextField(
                        key: ValueKey("Password"),
                        labelText: "Password",
                        isPassword: true,
                        ifChanged: (value) =>
                            Provider.of<LoginProvider>(context, listen: false)
                                .getPassword(value),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        width: 270,
                        height: 50,
                        child: ElevatedButton(
                          child: Text(
                            "Log in",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          onPressed: () {
                            if (_formKey.currentState.validate()) {
                              loginFunction();
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Colors.blue,
                            onPrimary: Colors.grey[100],
                            elevation: 1.7,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
