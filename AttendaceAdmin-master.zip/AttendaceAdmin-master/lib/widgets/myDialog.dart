import 'package:flutter/material.dart';

showMyDialog(BuildContext context, String title, String content, String actionTxt,
    {Function action}){
   showDialog(barrierDismissible: false ,context: context, builder: (ctx){
    return AlertDialog(
      title: Text(title),
      content: Text(content),
      actions: [
        TextButton(onPressed: (){
          Navigator.of(ctx).pop();
          action();
        }, child: Text(actionTxt))
      ],
    );
  });
}