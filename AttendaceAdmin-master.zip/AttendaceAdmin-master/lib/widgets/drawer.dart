import 'package:attendance_admin/screens/login/login_switch.dart';
import 'package:attendance_admin/screens/viewAll/admins.dart';
import 'package:attendance_admin/screens/viewAll/courses.dart';
import 'package:attendance_admin/screens/viewAll/departs.dart';
import 'package:attendance_admin/screens/viewAll/groups.dart';
import 'package:attendance_admin/screens/viewAll/instructors.dart';
import 'package:attendance_admin/screens/viewAll/students.dart';
import 'package:attendance_admin/widgets/drawerButtons.dart';
import 'package:flutter/material.dart';

Widget myDrawer(BuildContext context, Function logout){
  return Theme(
    data: ThemeData(
      canvasColor: Colors.transparent
    ),
    child: Drawer(
      elevation: 1.5,
      child: SafeArea(
        child: Container(
          color: Colors.black87.withOpacity(0.5),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: MediaQuery.of(context).size.height*0.15,),
                myTextButton(
                  title: "Instructors",
                  onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AllInstructors()));
                  }
                ),
                myTextButton(
                    title: "Students",
                    onPressed: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AllStudents()));
                    }
                ),
                myTextButton(
                    title: "Admins",
                    onPressed: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AllAdmins()));
                    }
                ),
                myTextButton(
                    title: "Groups",
                    onPressed: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AllGroups()));
                    }
                ),
                myTextButton(
                    title: "Courses",
                    onPressed: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AllCourses()));
                    }
                ),
                myTextButton(
                    title: "Departments",
                    onPressed: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (_)=> AllDeparts()));
                    }
                ),
                SizedBox(height: 40,),
                TextButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.logout, color: Colors.white,),
                      Text("Logout", style: TextStyle(
                        color: Colors.white,
                      ),),
                    ],
                  ),
                  onPressed: logout,
                )
              ],
            ),
          ),
        ),
      ),
    ),
  );
}