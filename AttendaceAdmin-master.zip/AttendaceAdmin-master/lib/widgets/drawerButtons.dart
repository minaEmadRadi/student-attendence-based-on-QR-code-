import 'package:flutter/material.dart';

Widget myTextButton({String title, Function onPressed}){
  return TextButton(
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: TextStyle(
          color: Colors.white,
        ),),
        Icon(Icons.arrow_forward_ios, color: Colors.white,),
      ],
    ),
    onPressed: onPressed,
  );
}