import 'package:flutter/material.dart';

Widget myCard({String txt, String imgUrl, Function onPress}) {
  return InkWell(
    child: Card(
      color: Colors.lightGreen,
      elevation: 1.7,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15)
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          height: 80,
          width: double.infinity,
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(15),bottomLeft :Radius.circular(15)),
                child: Container(
                  child: Image.asset(imgUrl, fit: BoxFit.cover,),
                  height: 80,
                  width: 80,
                ),
              ),
              Expanded(
                child: Center(
                  child: Text(txt, style: TextStyle(
                      color: Colors.white,
                      fontSize: 20
                  ),),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    onTap: onPress,
  );
}
