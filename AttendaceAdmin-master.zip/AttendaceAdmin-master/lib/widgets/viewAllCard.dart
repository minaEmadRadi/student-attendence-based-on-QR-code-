import 'package:flutter/material.dart';

Widget viewAllCard({String name, Function delete, Function edit}){
  return Container(
    padding: EdgeInsets.only(left: 8, right: 8),
    margin: EdgeInsets.only(top: 8),
    child: Card(
      color: Colors.white.withOpacity(0.9),
      elevation: 15,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(name, style: TextStyle(color: Colors.black, fontSize: 15), ),
            Row(
              children: [
                IconButton(icon: Icon(Icons.edit, color: Colors.blue,), onPressed: edit),
                Container(
                  height: 20, width: 0.5, color: Colors.black,
                ),
                IconButton(icon: Icon(Icons.delete_forever, color: Colors.red,), onPressed: delete),
              ],
            )
          ],
        ),
      ),
    ),
  );
}