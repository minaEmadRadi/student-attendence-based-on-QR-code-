import 'package:flutter/material.dart';

class AuthTextField extends StatelessWidget {
  final bool isPassword;
  final String labelText;
  final Function(String) ifChanged;
  final ValueKey key;

  const AuthTextField(
      {this.isPassword, this.labelText, this.ifChanged, this.key});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      key: key,
      onChanged: (value) => ifChanged(value),
      style: TextStyle(
        color: Colors.black87,
        fontSize: 15,
      ),
      keyboardType:
          !isPassword ? TextInputType.emailAddress : TextInputType.text,
      obscureText: isPassword,
      decoration: InputDecoration(
        border: UnderlineInputBorder(
          borderRadius: BorderRadius.circular(5),
        ),
        labelText: labelText,
        suffixIcon: Icon(isPassword ? Icons.lock : Icons.person),
      ),
      validator: (value){
        if(isPassword){
          if(value == null || value.length < 6 ){
            return "Please enter your valid password";
          }
          else{
            return null;
          }
        }else{
          if(value == null || !value.contains("@")){
            return "Please enter your valid email";
          } return null;
        }
      },
    );
  }
}
