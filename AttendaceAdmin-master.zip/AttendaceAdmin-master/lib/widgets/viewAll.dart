import 'package:attendance_admin/widgets/viewAllCard.dart';
import 'package:flutter/material.dart';

class ViewAll extends StatelessWidget {

  final List items;
  final String dialogTitle;
  final String dialogContent;
  final Function delete;
  final Function edit;


  const ViewAll({this.items, this.dialogTitle, this.dialogContent, this.delete, this.edit});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: items.length ,
        itemBuilder: (ctx, i) {
          return viewAllCard(
            name: items[i].name,
            edit: ()=> edit(i) ,
            delete: ()=> _showDeleteDialog(context, i),
          );
        });
  }

  _showDeleteDialog(BuildContext context, int i) {
    return showDialog(
        context: context,
        builder: (ctx){
          return AlertDialog(
            title: Text(dialogTitle),
            content: Text(dialogContent),
            actions: [
              TextButton(onPressed: (){
                Navigator.of(ctx).pop();
                delete(i);
              } , child: Text("Delete", style: TextStyle(color: Colors.red),)),
              TextButton(onPressed: ()=> Navigator.of(ctx).pop(), child: Text("Cancel")),
            ],
          );
        } );
  }
}
