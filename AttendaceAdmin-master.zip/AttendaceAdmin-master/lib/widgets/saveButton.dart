import 'package:flutter/material.dart';

Widget saveButton(Function onPress, {String title}){
  return Container(
    width: 170,
    height: 50,
    child: ElevatedButton(
      child: Text(
       title == null ? "Save" : title,
        style: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      onPressed: onPress,
      style: ElevatedButton.styleFrom(
        primary: Colors.blue,
        onPrimary: Colors.grey[100],
        elevation: 1.7,
      ),
    ),
  );
}