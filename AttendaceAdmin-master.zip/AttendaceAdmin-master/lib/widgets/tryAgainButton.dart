import 'package:flutter/material.dart';

Widget tryAgain(String error, Function retry) {
  print("Error is from TryAgain " + error.toString());
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Container(
        width: 170,
        height: 50,
        child: ElevatedButton(
          child: Text(
            "Try again",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          onPressed: retry,
          style: ElevatedButton.styleFrom(
            primary: Colors.lightGreen,
            onPrimary: Colors.grey[100],
            elevation: 1.7,
          ),
        ),
      ),
      SizedBox(height: 10),
      Text(
        error,
        style: TextStyle(color: Colors.white, fontSize: 18),
      ),
    ],
  );
}
