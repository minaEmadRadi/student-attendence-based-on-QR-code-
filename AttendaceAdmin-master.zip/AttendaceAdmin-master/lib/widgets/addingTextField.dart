import 'package:flutter/material.dart';

class AddingTextFormField extends StatelessWidget {
  final TextEditingController myController;
  final String labelText;
  final bool isPassword;
  final bool isEmail;
  final Function(String) myValidator;
  final ValueKey key;
  final Function(String) ifChanged;

  const AddingTextFormField(
      {this.myController, this.labelText, this.isPassword, this.isEmail, this.myValidator, this.key, this.ifChanged});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      key: key,
      controller: myController,
      decoration: InputDecoration(
        fillColor: Colors.white,
        border: UnderlineInputBorder(
          borderRadius: BorderRadius.circular(5),
        ),
        labelText: labelText,
      ),
      obscureText: isPassword,
      keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
      validator: (value)=> myValidator(value),
      onChanged: ifChanged == null ? (value){} : (value) => ifChanged(value)
      ,
    );
  }
}
