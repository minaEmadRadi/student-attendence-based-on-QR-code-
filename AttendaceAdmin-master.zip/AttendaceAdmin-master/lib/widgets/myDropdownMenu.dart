import 'package:attendance_admin/utilities/dropdownBorders.dart';
import 'package:flutter/material.dart';

Widget myDropdownMenu(
    {List<DropdownMenuItem> dropdownItems,
      Function onChanged(String id),
      String labelText,
      String validatorText,
      ValueKey key,
    }) {
  return DropdownButtonFormField<String>(
    key: key,
    decoration: InputDecoration(
      labelText: labelText,
      enabledBorder: myDropdownBorders(),
      focusedBorder: myDropdownBorders(),
      border: myDropdownBorders(),
      fillColor: Colors.white,
    ),
    items: dropdownItems,
    onChanged: (value) => onChanged(value),
    style: TextStyle(color: Colors.black),
    dropdownColor: Colors.white,
    validator: (v) {
      if (v == null) {
        return validatorText;
      } else {
        return null;
      }
    },
  );
}
