import 'package:attendance_admin/models/admin.dart';
import 'package:attendance_admin/models/course.dart';
import 'package:attendance_admin/models/department.dart';
import 'package:attendance_admin/models/group.dart';
import 'package:attendance_admin/models/instructor.dart';
import 'package:attendance_admin/models/student.dart';
import 'package:attendance_admin/services/dataFetchers.dart';
import 'package:attendance_admin/services/deleteObject.dart';
import 'package:attendance_admin/services/usersDataFetchers.dart';
import 'package:flutter/material.dart';

class DataProvider extends ChangeNotifier {
  String token = "";
  List<Student> students = [];
  List<Instructor> instructors = [];
  List<Group> groups = [];
  List<Course> courses = [];
  List<Admin> admins = [];
  List<Department> departs = [];
  bool deletionLoading = false;
  bool hasDataLoaded = false;

  tokenGetter(String takenToken) {
    token = takenToken;
    notifyListeners();
  }

  Future dataGetter(Future fetcher) async {
    var gottenValue;
    await fetcher.then((value) {
      gottenValue = value;
      hasDataLoaded = true;
      notifyListeners();
    }).catchError((onError) {
      throw onError;
    });
    return gottenValue;
  }

  Future<void> studentsGetter() async {
    await dataGetter(fetchStudents()).then((value) {
      students = value;
      notifyListeners();
    });
  }

  Future<void> instructorsGetter() async {
    await dataGetter(fetchInstructors()).then((value) {
      instructors = value;
      notifyListeners();
    });
  }

  Future<void> adminsGetter() async {
    await dataGetter(fetchAdmins()).then((value) {
      admins = value;
      notifyListeners();
    });
  }

  Future<void> groupsGetter() async {
    await dataGetter(DataFetchers.fetchGroups()).then((value) {
      groups = value;
      notifyListeners();
    });
  }

  Future<void> coursesGetter() async {
    await dataGetter(DataFetchers.fetchCourses()).then((value) {
      courses = value;
      notifyListeners();
    });
  }



  Future<void> departsGetter() async {
    await dataGetter(DataFetchers.fetchDeparts()).then((value) {
      departs = value;
      notifyListeners();
    });
  }

  Future<void> groupsAndDepartsGetter() async {
    departsGetter();
    groupsGetter();
  }

  changeDeletionLoading() {
    deletionLoading = !deletionLoading;
    notifyListeners();
  }

  resetDataLoadingVariable(){
    hasDataLoaded = false;
    notifyListeners();
  }


  Future deleteObject(
      {String objectType, String id, Function done, Function error}) async {
    changeDeletionLoading();
    hasDataLoaded = true;
    notifyListeners();
    await Deletion.deleteObject(objectType, id, token).then((value) {
      done(value);
      changeDeletionLoading();
    }).catchError((onError) {
      error(onError);
      changeDeletionLoading();
    });
  }


}
