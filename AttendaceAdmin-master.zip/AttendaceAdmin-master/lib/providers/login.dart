import 'dart:convert';

import 'package:attendance_admin/services/loginServices.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/*

      int age = 18;


      void changeAge(){
        age = 20;
        notifyListeners();
      }

      Text(age);
 */

class LoginProvider extends ChangeNotifier {
  bool isLoading = false;
  String token;
  String role = "";
  String userId = "";
  String _email = "";
  String _password = "";

  bool get isAuth {
    return token != null;
  }

  void getEmail(String enteredEmail) {
    _email = enteredEmail;
    notifyListeners();
  }

  void getPassword(String enteredPassword) {
    _password = enteredPassword;
    notifyListeners();
  }

  Future login() async {
    isLoading = true;
    notifyListeners();
    await LoginService.login({"email": _email, "password": _password})
        .then((value) {
      Map<String, Object> tokens = value['tokens'];
      Map<String, Object> access = tokens['access'];
      Map<String, Object> userData = value['user'];
      role = userData['role'];
      userId = userData['_id'];
      token = access['token'];
      isLoading = false;
      notifyListeners();
      saveLoginDataLocally();
    }).catchError((onError) {
      isLoading = false;
      notifyListeners();
      throw onError;
    });
  }

  Future adminLogin({Function done, Function error}) async {
    await login().catchError((onError) {
      throw onError;
    }).then((_) {
      if (role == "admin") {
        done();
      } else {
        error();
        clearWrongCredentials();
      }
    });
  }

  Future instructorLogin({Function done, Function error}) async {
    await login().catchError((onError) {
      throw onError;
    }).then((_) {
      if (role == "instructor") {
        done();
      } else {
        error();
        clearWrongCredentials();
      }
    });
  }

  clearWrongCredentials() async {
    token = "";
    role = "";
    userId = "";
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    _prefs.remove('loginData');
    notifyListeners();
  }

  logout() async {
    token = "";
    role = "";
    userId = "";
    notifyListeners();
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    _prefs.remove('loginData');
  }

  saveLoginDataLocally() async {
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    //Save this object as a String
    _prefs.setString(
      'loginData',
      json.encode({'token': token, 'role': role, 'id': userId}),
    );
  }

  Future<bool> tryAutoLogin({Function forAdmin, Function forInstructor}) async {
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    String loginData = _prefs.getString('loginData');
    if (loginData != null) {
      Map<String, Object> data = json.decode(loginData);
      token = data['token'];
      role = data['role'];
      userId = data['id'];
      notifyListeners();
      return true;
    } else if (loginData == null) {
      return false;
    } else {
      return false;
    }
  }
}
