import 'package:attendance_admin/models/course.dart';
import 'package:attendance_admin/services/dataFetchers.dart';
import 'package:attendance_admin/utilities/dropdownBorders.dart';
import 'package:flutter/material.dart';
import '../../services/createUser.dart';

class AddInstructorProvider extends ChangeNotifier {
  List<String> coursesIds = [];
  bool isLoading = false;
  String token;
  bool hasCoursesLoaded = false;
  List<Course> courses = [];
  Map<String  , DropdownButtonFormField<String>> myDropDowns = {};

  tokenGetter(String takenToken) {
    token = takenToken;
    notifyListeners();
  }

  Future coursesGetter() async{

    await DataFetchers.fetchCourses().then((value) async{
      courses = value;
      hasCoursesLoaded = true;
      notifyListeners();
      });
  }

  resetCoursesLoading(){
    hasCoursesLoaded = false;
    coursesIds = [];
    myDropDowns = {};
    notifyListeners();
  }

  void changeLoading() {
    isLoading = !isLoading;
    notifyListeners();
  }

  void addMoreCourse() {
    String  newCourseKey = UniqueKey().toString();
    myDropDowns.putIfAbsent(newCourseKey, () => DropdownButtonFormField<String>(
      key: ValueKey("$newCourseKey"),
      onSaved: (value) => addCourseIdToList(value),
      onChanged: (value) {},
      decoration: InputDecoration(
        prefixIcon:  IconButton(
            icon: Icon(
              Icons.close,
              color: Colors.red,
            ),
            onPressed: () => decreaseCourse(newCourseKey)),
        suffixIcon: IconButton(
          onPressed: addMoreCourse,
          icon: Icon(
            Icons.add,
            color: Colors.blue,
          ),
        ),
        labelText: "Courses",
        enabledBorder: myDropdownBorders(),
        focusedBorder: myDropdownBorders(),
        border: myDropdownBorders(),
        fillColor: Colors.white,
      ),
      items: courses.map((e) {
        return DropdownMenuItem<String>(
          child: Text(e.name),
          value: e.id,
        );
      }).toList(),
      style: TextStyle(color: Colors.black),
      dropdownColor: Colors.white,
    ));
    notifyListeners();
  }

  addCourseIdToList(String id) {
    if (!coursesIds.contains(id)) {
      coursesIds.add(id);
    }
    notifyListeners();
  }

  void decreaseCourse(String key) {
    myDropDowns.remove(key);
    notifyListeners();
  }



  Future createNewInstructor(
      {String myName,
      String myEmail,
      String myPassword,
      Function done,
      Function error}) async {
    changeLoading();
    await UserCreator.createUser(
      token: token,
      role: "instructor",
      name: myName,
      email: myEmail,
      password: myPassword,
      courses: coursesIds,
    ).then((value) {
      changeLoading();
      done(value);
    }).catchError((onError) {
      changeLoading();
      error(onError);
    });
  }
}
