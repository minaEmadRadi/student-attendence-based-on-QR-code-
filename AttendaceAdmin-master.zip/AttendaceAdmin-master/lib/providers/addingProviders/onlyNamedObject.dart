import 'package:attendance_admin/services/namedObjectCreator.dart';
import 'package:flutter/material.dart';

class AddNamedObject extends ChangeNotifier{
  bool isLoading = false;
  String token = "" ;

  tokenGetter(String takenToken){
    token = takenToken;
    notifyListeners();
  }
  changeLoading(){
    isLoading = !isLoading;
    notifyListeners();
  }
  Future _createNew({String myName, Function done, Function error, String url}) async{
    changeLoading();
    await NamedObjectCreator.createObject(
      urlSegment: url,
      token: token,
      name: myName,
    ).then((value){
      changeLoading();
      done(value);
    }).catchError((onError){
      changeLoading();
      error(onError);
    });
  }

  createNewGroup({String myName, Function done, Function error}) async{
   await _createNew(
      myName: myName,
      done: done,
      error: error,
      url: "group"
    );
  }
  createNewDepart({String myName, Function done, Function error}) async{
   await _createNew(
        myName: myName,
        done: done,
        error: error,
        url: "department"
    );
  }
  createNewCourse({String myName, Function done, Function error}) async{
    await _createNew(
        myName: myName,
        done: done,
        error: error,
        url: "course"
    );
  }
}