import 'package:attendance_admin/models/department.dart';
import 'package:attendance_admin/models/group.dart';
import 'package:attendance_admin/services/dataFetchers.dart';
import 'package:flutter/material.dart';
import '../../services/createUser.dart';


class AddStudentProvider extends ChangeNotifier{

  Group selectedGroup = Group();
  String selectedGroupID = "";
  String selectedDepartID = "60a96b93c5501b00047a9918";
  List<Group> groups = [];
  List<Department> departs = [];
  String token = "";
  bool isLoading = false;
  bool hasDataLoaded = false;

  void changeLoading(){
    isLoading = !isLoading;
    notifyListeners();
  }

  dataGetter(String takenToken){
    token = takenToken;
    notifyListeners();
  }

  resetVariables(){
    hasDataLoaded = false;
    notifyListeners();
  }

  Future getGroupsDeparts() async{

    await DataFetchers.fetchGroups().then((value) async{
      groups = value;
      notifyListeners();
      await DataFetchers.fetchDeparts().then((value){
        value.removeWhere((element) => element.name == "General");
        departs = value;
        notifyListeners();
      });
    });
    hasDataLoaded = true;
    notifyListeners();
  }

  saveGroupID(String id){
    selectedGroup = groups.firstWhere((element) => element.id == id);
    selectedGroupID = id;
    notifyListeners();
  }

   saveDepartID(String id){
    selectedDepartID = id;
    notifyListeners();
  }

  clearSelections(){
    selectedGroup = Group();
    notifyListeners();
  }

  createNewStudent({String myName, String myEmail, String myPassword, Function done, Function error}) async{
    changeLoading();
    await UserCreator.createUser(
      role: "student",
      token: token,
      name: myName,
      email: myEmail,
      password: myPassword,
      group: selectedGroupID,
      depart: selectedDepartID,
    ).then((value){
      changeLoading();
      clearSelections();
      done(value);
    }).catchError((onError){
      changeLoading();
      error(onError);
    });
  }

}