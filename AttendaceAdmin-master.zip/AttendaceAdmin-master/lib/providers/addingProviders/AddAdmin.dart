import 'package:flutter/material.dart';
import '../../services/createUser.dart';

class AddAdminProvider extends ChangeNotifier{

  bool isLoading = false;
  String token = "";

  tokenGetter(String takenToken){
    token = takenToken;
    notifyListeners();
  }

  changeLoading(){
    isLoading = !isLoading;
    notifyListeners();
  }

  createNewAdmin({String myName, String myEmail, String myPassword, Function done, Function error}) async{
    changeLoading();
    await UserCreator.createUser(
      role: "admin",
      token: token,
      name: myName,
      email: myEmail,
      password: myPassword,
    ).then((value){
      changeLoading();
      done(value);
    }).catchError((onError){
      changeLoading();
      error(onError);
    });
  }

}