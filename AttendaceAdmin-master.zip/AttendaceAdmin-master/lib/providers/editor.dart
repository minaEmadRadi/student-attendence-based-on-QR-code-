import 'package:attendance_admin/models/department.dart';
import 'package:attendance_admin/models/group.dart';
import 'package:attendance_admin/services/dataFetchers.dart';
import 'package:attendance_admin/services/editors.dart';
import 'package:flutter/material.dart';

class EditorProvider extends ChangeNotifier {
  bool isLoading = false;
  bool hasDataLoaded = false;
  String selectedGroupId = "";
  String selectedDepartId = "60d8fba804101a0004b35707";
  String changedGroupId = "";
  List<Group> groups = [Group(id: "null", name: "null")];
  List<Department> departs = [Department(id: "null", name: "null")];
  List<String> groupIDs = [];
  List<String> departIDs = [];
  String token = "";
  bool hasGroupChanged = false;

  tokenGetter(String takenToken) {
    token = takenToken;
    notifyListeners();
  }

  Future getGroupsDeparts() async {
    await DataFetchers.fetchGroupsDeparts().then((value){
      groups = value['groups'];
      List<Department> tempDeparts = value['departs'];
      tempDeparts.removeWhere((element) => element.id == "60d8fba804101a0004b35707" );
      departs = tempDeparts;
      notifyListeners();
    });
    hasDataLoaded = true;
    groupIDs = groups.map((e) {
      return e.id;
    } ).toList();
    departIDs = departs.map((e){
      return e.id;
    }).toList();
    notifyListeners();
  }

  void changeLoading() {
    isLoading = !isLoading;
    notifyListeners();
  }


  void onGroupChange(String id) {
    changedGroupId = id;
    hasGroupChanged = true;
    notifyListeners();
  }

  void saveGroupId(String id) {
    selectedGroupId = id;
    notifyListeners();
  }

  void saveDepartId(String id) {
    selectedDepartId = id;
    notifyListeners();
  }

  void resetVariables(){
    changedGroupId = "";
    hasGroupChanged = false;
    hasDataLoaded = false;
    notifyListeners();
  }


  Future editObject({
    String name,
    String email,
    String id,
    Function done,
    Function error,
    bool isStudent,
    String objectType,
  }) async {
    changeLoading();
    Map<String, String> body;
    if(selectedGroupId != groups.last.id){
      selectedDepartId = "60d8fba804101a0004b35707";
      notifyListeners();
    }
    if(objectType == "user"){
      if (isStudent) {
        body = {
          "name": name,
          "email": email,
          "group": selectedGroupId,
          "department": selectedDepartId,
        };
        notifyListeners();
      } else {
        body = {
          "name": name,
          "email": email,
        };
        notifyListeners();
      }
    }else{
      body = {
        "name" : name,
      };
      notifyListeners();
    }
    await EditorServices.objectEditor(
      urlSegment: objectType,
      token: token,
      id: id,
      myBody: body,
    ).then((value) {
      changeLoading();
      done(value);
    }).catchError((onError) {
      changeLoading();
      error(onError);
    });
  }

}
