import 'dart:convert';

import 'package:attendance_admin/models/course.dart';
import 'package:attendance_admin/models/student.dart';
import 'package:attendance_admin/services/dataFetchers.dart';
import 'package:attendance_admin/services/recordFetcher.dart';
import 'package:attendance_admin/services/usersDataFetchers.dart';
import 'package:flutter/material.dart';

class InstructorHomeProvider extends ChangeNotifier {
  String selectedCourseId = "";
  String selectedStartTime = "";
  String selectedEndTime = "";
  String token;
  String id;
  List instructorCoursesIds;
  List<Course> allCourses = [Course(id: "null", name: "null")];
  List<Course> instructorCourses = [Course(id: "null", name: "null")];
  DateTime courseDate = DateTime.now();
  List<String> times = [
    "8 AM",
    "8.30 AM",
    "9 AM",
    "9.30 AM",
    "10 AM",
    "10.30 AM",
    "11 AM",
    "11.30 AM",
    "12 PM",
    "12.30 PM",
    "1 PM",
    "1.30 PM",
    "2 PM",
    "2.30 PM",
    "3 PM",
    "3.30 PM",
    "4 PM",
    "4.30 PM",
    "5 PM",
    "5.30 PM",
    "6 PM",
    "6.30 PM",
  ];

  String qrDifferential = "AttendanceIsDone";

  Map<String, String> qrData = {
    "course": "",
    "startsAt": "",
    "endsAt": "",
    "date": "${DateTime.now().month}-${DateTime.now().day}-${DateTime.now().year}"
  };

  String encodedData = "";

  bool isError = false;
  bool isLoading = true;
  bool hasDataLoaded = false;

  List<Student> attendedStudents = [];
  bool notFound = false;

  dataGetter(String takenToken, String takenId) {
    token = takenToken;
    id = takenId;
    notifyListeners();
  }

  void saveSelectedCourse(String courseId) {
    selectedCourseId = courseId;
    qrData["course"] = selectedCourseId;
    notifyListeners();
  }

  void saveSelectedStart(String startTime) {
    selectedStartTime = startTime;
    qrData["startsAt"] = selectedStartTime;
    notifyListeners();
  }

  void saveSelectedEnd(String endTime) {
    selectedEndTime = endTime;
    qrData["endsAt"] = selectedEndTime;
    notifyListeners();
  }

  encodeData() {
    encodedData = json.encode(qrData);
    notifyListeners();
  }

  Future allCoursesGetter() async {
    await DataFetchers.fetchCourses().then((value) {
      allCourses = value;
      notifyListeners();
    }).catchError((onError) {
      throw onError;
    });
  }

  Future instructorCoursesIdGetter() async {
    isLoading = true;
    notifyListeners();
    await fetchSpecificInstructorCourses(id).then((value) {
      instructorCoursesIds = value;
      isError = false;
      isLoading = false;
      hasDataLoaded = true;
      notifyListeners();
    }).catchError((onError) {
      isError = true;
      isLoading = false;
      notifyListeners();
      throw onError;
    });
  }

  Future<bool> instructorCoursesGetter() async {
    await allCoursesGetter();
    await instructorCoursesIdGetter();
    instructorCourses = allCourses
        .where((element) => instructorCoursesIds.contains(element.id))
        .toList();
    notifyListeners();
    return true;
  }

  getSelectedDate(DateTime _date) {
    courseDate = _date;
    notifyListeners();
  }

  Future fetchAttendanceRecords() async {
    await RecordsServices.fetch({
      "date": "${courseDate.month}/${courseDate.day}/${courseDate.year}",
      "course": selectedCourseId,
    }).then((value) {
      if (value["notFound"] == false) {
        attendedStudents = value["students"];
        notFound = false;
        notifyListeners();
      } else if (value["notFound"] == true) {
        notFound = true;
        notifyListeners();
      }
    }).catchError((onError) {
      throw onError;
    });
  }
}
