import 'package:flutter/material.dart';

class Student {
  final String id;
  final String name;
  final String groupId;
  final String departId;
  final String role;
  final String email;

  Student(
      {@required this.groupId,
      @required this.departId,
      @required this.email,
      @required this.role,
      @required this.id,
      @required this.name});

  factory Student.fromJson(Map<String, Object> jsonData) {
    return Student(
      name: jsonData['name'],
      id: jsonData['_id'],
      departId: jsonData['department'],
      groupId: jsonData['group'],
      role: jsonData['role'],
      email: jsonData['email'],
    );
  }
}
