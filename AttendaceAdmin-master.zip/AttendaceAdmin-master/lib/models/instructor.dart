import 'package:flutter/material.dart';

class Instructor {
  final String name;
  final String id;
  final List coursesIDs;
  final String email;

  Instructor(
      {@required this.name, @required this.id, @required this.coursesIDs, @required this.email});

  factory Instructor.fromJson(Map<String, Object> jsonData) {
    return Instructor(
        name: jsonData['name'],
        id: jsonData['_id'],
        coursesIDs: jsonData['courses'],
      email: jsonData['email']
    );
  }
}
