import 'package:flutter/material.dart';

class Admin {
  final String name;
  final String id;
  final String email;

  Admin({
    @required this.name,
    @required this.id,
    @required this.email,
  });

  factory Admin.fromJson(Map<String, Object> map) {
    return Admin(
      name: map['name'],
      id: map['_id'],
      email: map['email'],
    );
  }

  /*
      {
      "name" : "mohamed",
      "_id: "12",
      "email" : "moahmed@gmail.com"
      }
   */

  void test() {
    String t = "";
    Map<String, String> map = Map();
    map["name"] = "mohamed";

    map["name"] = "asdsda";

    print(map["name"]);
  }
}
