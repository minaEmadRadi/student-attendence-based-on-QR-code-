import 'package:flutter/material.dart';

class Course {
  final String name;
  final String id;

  Course({@required this.name,@required this.id});

  factory Course.fromJson(Map<String, Object> jsonData) {
    return Course(
      name: jsonData['name'],
      id: jsonData['_id'],
    );
  }

}