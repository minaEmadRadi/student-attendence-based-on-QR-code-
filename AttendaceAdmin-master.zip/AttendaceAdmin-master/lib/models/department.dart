import 'package:flutter/material.dart';

class Department {
  final String id;
  final String name;

  Department({@required this.id, @required this.name});

  factory Department.fromJson(Map<String, Object> jsonData) {
    return Department(
      name: jsonData['name'],
      id: jsonData['_id'],
    );
  }
}
