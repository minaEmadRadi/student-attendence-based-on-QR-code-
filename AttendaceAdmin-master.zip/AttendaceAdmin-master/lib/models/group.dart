import 'package:flutter/material.dart';

class Group {
  final String name;
  final String id;

  Group({@required this.name, @required this.id});

  factory Group.fromJson(Map<String, Object> jsonData){
    return Group(
      name: jsonData['name'],
      id: jsonData['_id'],
    );
  }
}
